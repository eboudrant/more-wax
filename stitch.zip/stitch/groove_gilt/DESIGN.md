# Design System: The Modern-Classic Collector’s Framework

## 1. Overview & Creative North Star: "The Digital Archivist"
This design system is built on the philosophy of **The Digital Archivist**. We are not building a utility app; we are building a high-end gallery for physical artifacts. The "Modern-Classic" aesthetic is achieved by juxtaposing the raw, tactile nature of vinyl with the precision of contemporary digital design.

**The Creative North Star** is defined by three pillars:
*   **Intentional Asymmetry:** Break the rigid 12-column grid. Align text to the left while imagery sits slightly off-center or overlaps containers to create an editorial, magazine-like flow.
*   **Depth through Tonal Gravity:** We eschew lines and borders in favor of "stacking" surfaces. The UI should feel like a series of heavy, premium cardstocks layered on a dark oak table.
*   **The Heroic Focal Point:** Every screen must have one undisputed hero—usually the album art—around which all typography and navigation orbit.

---

## 2. Colors & Surface Philosophy
The palette is rooted in deep obsidian and charcoal to allow the vibrant CMYK colors of album jackets to vibrate against the background.

### The "No-Line" Rule
**Strict Mandate:** Designers are prohibited from using 1px solid borders (`outline`) for sectioning. Structural boundaries must be defined solely through:
1.  **Background Shifts:** Use `surface_container_low` for the main body and `surface_container_high` for elevated modules.
2.  **Negative Space:** Use the `16` (5.5rem) or `20` (7rem) spacing tokens to create mental resets between content blocks.

### Surface Hierarchy & Nesting
Treat the UI as a physical stack. 
*   **Base:** `background` (#131313)
*   **Content Areas:** `surface_container` (#201f1f)
*   **Interactive Cards:** `surface_container_high` (#2a2a2a)
*   **Floating Modals/Overlays:** `surface_container_highest` (#353534) with a `surface_tint` at 5% opacity.

### The Glass & Gradient Rule
To prevent a "flat" digital look, use **Glassmorphism** for navigation bars and playing-now drawers. 
*   **Token:** Use `surface` at 80% opacity with a `backdrop-filter: blur(20px)`.
*   **Signature Gradient:** For primary CTAs (e.g., "Add to Collection"), apply a linear gradient from `primary` (#fddcb1) to `primary_container` (#e0c097) at a 135-degree angle. This adds "soul" and weight to the interaction.

---

## 3. Typography: The Editorial Mix
We use a high-contrast pairing: **Noto Serif** for prestige and storytelling, and **Manrope** for data-heavy utility.

*   **Display & Headline (Noto Serif):** Used for Album Titles, Artist Names, and Editorial Headers. These should be set with tight letter-spacing (-0.02em) to feel authoritative.
    *   *Example:* `display-lg` (#e5e2e1) for the main artist name on a profile.
*   **Title & Body (Manrope):** Used for tracklists, metadata (BPM, Year, Pressing), and descriptions. 
    *   *Example:* `body-md` (#d1c4b8) for liner notes to ensure long-form readability.
*   **Label (Manrope Mono-style):** Use `label-md` in all-caps with +0.1em letter spacing for technical specs (e.g., "180G VIRGIN VINYL").

---

## 4. Elevation & Depth
Depth in this system is organic, not synthetic.

*   **The Layering Principle:** Instead of a drop shadow, place a `surface_container_lowest` (#0e0e0e) card behind a `surface_container` (#201f1f) element to create a "recessed" look. 
*   **Ambient Shadows:** If an element must float (like a FAB), use a blur of `40px` with the color `surface_container_lowest` at 40% opacity. Avoid black shadows; use the "darkest surface" color to maintain a naturalistic light spill.
*   **The Ghost Border:** If a boundary is required for accessibility on high-contrast images, use `outline_variant` (#4e453c) at **15% opacity**. It should be felt, not seen.

---

## 5. Components

### Cards & Lists (The Gallery Model)
*   **The Rule:** No dividers. Use `surface_container_low` for the list background and `surface_container` for the individual item on hover.
*   **Spacing:** Use `spacing-4` (1.4rem) between list items to let the typography breathe.
*   **Album Art:** Use the `lg` (0.5rem) roundedness scale. This mimics the slightly blunted corners of a real vinyl sleeve.

### Buttons
*   **Primary:** Gradient of `primary` to `primary_container`. Text: `on_primary` (#402d0f). Shape: `full` (pill) for high-frequency actions.
*   **Secondary:** Ghost style. No fill, `outline` at 20% opacity. Text: `on_surface`.
*   **Tertiary:** Text-only using `primary_fixed_dim`. Use for "Cancel" or "View All".

### Inputs & Search
*   **Style:** Minimalist. No box. Use a bottom-only border of `outline_variant` at 40% opacity. 
*   **Focus State:** The bottom border transitions to `primary` (#fddcb1) and the label (Noto Serif) shifts slightly to the left, breaking the vertical alignment for an editorial "flicker."

### Chips (Genre & Tags)
*   **Style:** `surface_container_high` background with `on_surface_variant` text. 
*   **Shape:** `DEFAULT` (0.25rem) roundedness to contrast with the pill-shaped buttons.

---

## 6. Do’s and Don’ts

### Do
*   **Do** use overlapping elements. Let the corner of an album cover slightly obscure a `display-sm` heading to create depth.
*   **Do** use `primary_fixed` (#ffddb2) for gold-standard highlights like "Limited Edition" or "Rare."
*   **Do** prioritize imagery. If an album cover is low-res, use a blurred version of it as the `surface_dim` background to maintain the mood.

### Don’t
*   **Don’t** use pure white (#FFFFFF). It is too harsh for the "Modern-Classic" vibe. Always use `on_surface` (#e5e2e1).
*   **Don’t** use 1px dividers to separate tracks in a list. Use `spacing-2` and `spacing-3` to create grouping.
*   **Don’t** use standard "Material Design" blue for links. Use `tertiary` (#d2e2fd) or `primary`.
*   **Don’t** use `full` rounding for everything. Reserve it for buttons. Everything else should feel structural and architectural using `lg` or `md` corners.